module.exports = {
    token: "", //(Bot Tokeniniz)
    prefix: ".", //   (Botunuzun ön eki )
    mongoUrl: "mongodb+srv://", //(database => mongdodb urlniz)
    owners: ["1179280051443867728"], //(Bot Owner Idleri Bazı komutlarda gerekli "", le çoğaltabilirsiniz)
    guildID: "1390384554673438820", // (Botun Olduğu Sunucu Id)
    logChannel: "1391454270519509072", // (Logların Gönderileceği Kanal Idsi)
};
///Metehan Studio AİLESİ /// Metehan Studio AİLESİ /// Metehan Studio AİLESİ ///Metehan Studio AİLESİ  Metehan Studio AİLESİ  Metehan Studio AİLESİ 