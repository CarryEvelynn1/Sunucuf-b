# Metehan Studio - Discord Guard Bot 
_____________________________________________________________________________________________________________

Piyasada ki v12-v13 hatalı guard altyapılarından sıkıldınız mı? Discord sunucunuzu korumak, yedeklemek ve yönetmek için harika bir yazılım. Üstelik webpanel entegreli, hazır şekilde.

Kullanıcı dostu arayüzü ve gelişmiş özellikleriyle sunucunuzu düzene sokmanızı sağlar. Sadece birkaç basit komutla ayarları sıfırlayabilir, kurabilir ve yönetebilirsiniz.

_____________________________________________________________________________________________________________


🚀  Discord Guard Bot v1

✅  Kanal koruması & Rol Koruması

✅  Emoji Koruması & Ban/Kick Koruması

✅  Whitelist & Safe kullanıcı sistemi

✅  Detaylı log kanalı ayarlama sistemleri

✅  Canvas modülüyle resimli modern komutlar

✅  Web panelden bota özel komut ekleme sistemi

✅  Web panelden sunucuya duyuru atabilme sistemi

✅  Discord.js v14 ve geliştirilmeye açık temiz altyapı

✅  Web panelden bütün logları & bütün işlemleri görebilme

✅  Hem webpanel üzerinden hem bot üzerinden yönetme imkanı

✅  Kanalları & rolleri & sunucuyu yedek alma ve yedek yükleme

✅  ve çok daha fazlası... 

_____________________________________________________________________________________________________________

Kurulum Videosu ve Sesli Tanıtım

https://www.youtube.com/watch?v=QXh-bAcQLNw&t=77s

_____________________________________________________________________________________________________________

Website: https://metehanstudio.com

Destek sunucusu: https://discord.gg/medya

Emeği Geçenler: [Muti](https://github.com/Mutifordev) & [Mete](https://github.com/Meteeey)

_____________________________________________________________________________________________________________

🛡️  Telif Hakkı ve Lisans

Bu altyapının, içeriğinin ve görsellerinin izinsiz kopyalanması, yeniden dağıtılması veya satılması yasaktır. Tespiti hâlinde yasal işlemler derhal başlatılır.

[![DMCA Badge](https://images.dmca.com/Badges/dmca-badge-w100-5x1-01.png)](https://www.dmca.com/r/1q3ggm9)

_____________________________________________________________________________________________________________

🔥  Altyapıdan Bazı Görseller

<img width="2153" height="1220" alt="image" src="https://github.com/user-attachments/assets/6d93b983-3352-405d-b3ff-0f66599f0d16" />
<img width="2162" height="938" alt="image" src="https://github.com/user-attachments/assets/2c288026-6ff5-41e6-bbd0-7f84d5ba6d75" />
<img width="2225" height="811" alt="image" src="https://github.com/user-attachments/assets/f6f7d2da-0530-480e-a942-1475f7be8727" />
<img width="2135" height="831" alt="image" src="https://github.com/user-attachments/assets/2447bcb4-0603-43a4-a9dd-836d40a21a67" />
<img width="2841" height="1690" alt="image" src="https://github.com/user-attachments/assets/9f3d49c0-18e0-48d5-b709-8b315fbe3720" />
<img width="2419" height="1709" alt="image" src="https://github.com/user-attachments/assets/a9ea5053-7b31-46be-8db4-f3bcf43ee6bb" />
<img width="2347" height="1714" alt="image" src="https://github.com/user-attachments/assets/d5ae41e8-bea1-4f09-9f96-360ff37217c0" />
<img width="2355" height="1711" alt="image" src="https://github.com/user-attachments/assets/78352930-a452-4c0a-a7ee-2b40d8e78e44" />
<img width="2355" height="1711" alt="image" src="https://github.com/user-attachments/assets/03cc4f9e-4394-4e4e-9a36-ea207cdaadb1" />








